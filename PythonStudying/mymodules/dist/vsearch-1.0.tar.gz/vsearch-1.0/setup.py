from setuptools import setup

setup(
    name='vsearch', #важливо
    version='1.0',
    description='Search Tools',
    author='me',
    url='vsearch.com',
    py_modules=['vsearch'], #важливо
)